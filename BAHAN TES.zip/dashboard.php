<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="container mt-2">
    <p>Ini adalah Halaman Dashboard
        <br>Selamat datang di <b>Maldin17</b>App!
    </p>
</div>
<?= $this->endSection() ?>